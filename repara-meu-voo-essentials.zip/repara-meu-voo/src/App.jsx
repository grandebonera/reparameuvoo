import './App.css'
import Header from './components/layout/Header'
import Footer from './components/layout/Footer'
import HeroSection from './components/sections/HeroSection'
import CredibilitySection from './components/sections/CredibilitySection'
import CategoriesSection from './components/sections/CategoriesSection'
import ProcessSection from './components/sections/ProcessSection'
import StatisticsSection from './components/sections/StatisticsSection'
import HowItWorksSection from './components/sections/HowItWorksSection'
import PricingSection from './components/sections/PricingSection'
import ComparisonSection from './components/sections/ComparisonSection'
import RightsSection from './components/sections/RightsSection'
import FAQSection from './components/sections/FAQSection'

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-16">
        <HeroSection />
        <CredibilitySection />
        <CategoriesSection />
        <ProcessSection />
        <StatisticsSection />
        <HowItWorksSection />
        <PricingSection />
        <ComparisonSection />
        <RightsSection />
        <FAQSection />
      </main>
      <Footer />
    </div>
  )
}

export default App
