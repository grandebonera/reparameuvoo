import { Button } from '@/components/ui/button';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Repara meu voo</h3>
            <ul className="space-y-2">
              <li><a href="#sobre" className="text-gray-300 hover:text-white transition-colors">Sobre nós</a></li>
              <li><a href="#portal" className="text-gray-300 hover:text-white transition-colors">Portal</a></li>
              <li><a href="#depoimentos" className="text-gray-300 hover:text-white transition-colors">Depoimentos</a></li>
              <li><a href="#como-funciona" className="text-gray-300 hover:text-white transition-colors">Como funciona</a></li>
              <li><a href="#privacidade" className="text-gray-300 hover:text-white transition-colors">Política de privacidade</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Explore</h3>
            <ul className="space-y-2">
              <li><a href="#processar" className="text-gray-300 hover:text-white transition-colors">Como processar uma empresa</a></li>
              <li><a href="#advogados" className="text-gray-300 hover:text-white transition-colors">Diretório de advogados</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Seus Direitos</h3>
            <ul className="space-y-2">
              <li><a href="#voo-cancelado" className="text-gray-300 hover:text-white transition-colors">Voo cancelado</a></li>
              <li><a href="#voo-atrasado" className="text-gray-300 hover:text-white transition-colors">Voo atrasado</a></li>
              <li><a href="#conexao-perdida" className="text-gray-300 hover:text-white transition-colors">Conexão perdida</a></li>
              <li><a href="#no-show" className="text-gray-300 hover:text-white transition-colors">Cancelamento por no-show</a></li>
              <li><a href="#overbooking" className="text-gray-300 hover:text-white transition-colors">Overbooking</a></li>
              <li><a href="#bagagem" className="text-gray-300 hover:text-white transition-colors">Extravio de bagagem</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Fale conosco</h3>
            <p className="mb-2">Dúvidas? Acesse nosso F.A.Q.</p>
            <p className="mb-4">Precisa de ajuda?<br />atendimento@reparameuvoo.com.br</p>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white w-full">
              Verificar meu caso grátis
            </Button>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center">
          <div className="text-xl font-bold mb-4">Repara meu voo</div>
          <p>© Repara meu voo Tecnologia LTDA | CNPJ: 00.000.000/0001-00</p>
          <p>Av. Exemplo, 1000 - Centro, São Paulo - SP, 00000-000</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

