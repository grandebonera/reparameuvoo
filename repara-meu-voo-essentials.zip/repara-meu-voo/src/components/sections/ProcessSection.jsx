const ProcessSection = () => {
  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Sem burocracia, como você merece
        </h2>
        <p className="text-xl mb-12 max-w-3xl mx-auto">
          Nossa tecnologia permite que você busque seus direitos sem complicações
        </p>
        
        <div className="max-w-xs mx-auto">
          <div className="border-8 border-gray-800 rounded-3xl overflow-hidden">
            <div className="bg-white h-96 flex items-center justify-center">
              <p className="text-gray-400">Interface do aplicativo</p>
            </div>
          </div>
          <div className="w-24 h-6 bg-gray-800 mx-auto rounded-b-xl"></div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;

