const PricingSection = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Quanto custa usar o Repara meu voo?
        </h2>
        <p className="text-xl mb-12 max-w-3xl mx-auto">
          Trabalhamos para o seu sucesso. Se não conseguirmos que sua indenização seja paga, 
          não cobramos nada pelo nosso serviço. Sem pegadinhas.
        </p>
        
        <div className="max-w-md mx-auto">
          <div className="relative">
            <div className="w-64 h-64 bg-pink-200 rounded-full mx-auto"></div>
            <p className="mt-8 text-xl font-medium">
              A Repara meu voo fica com 35% após a resolução do caso
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;

