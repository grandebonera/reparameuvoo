import { Star } from 'lucide-react';

const CredibilitySection = () => {
  const testimonials = [
    {
      id: 1,
      text: "Serviço excelente! Consegui minha indenização em tempo recorde e sem nenhuma dor de cabeça.",
      author: "Carlos Silva",
      location: "São Paulo"
    },
    {
      id: 2,
      text: "Após ter meu voo cancelado, o Repara meu voo resolveu tudo para mim. Recomendo a todos!",
      author: "Ana Oliveira",
      location: "Rio de Janeiro"
    },
    {
      id: 3,
      text: "Processo simples e transparente. Recebi minha indenização sem precisar me preocupar com burocracia.",
      author: "Marcos Santos",
      location: "Belo Horizonte"
    }
  ];

  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-8">
          Avaliação de excelência no mercado
        </h2>
        
        <div className="flex justify-center mb-10">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-10 h-10 text-yellow-400 fill-yellow-400" />
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-white p-8 rounded-lg shadow-md"
            >
              <p className="italic mb-6 text-gray-700">"{testimonial.text}"</p>
              <div className="font-bold">
                {testimonial.author}, {testimonial.location}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CredibilitySection;

