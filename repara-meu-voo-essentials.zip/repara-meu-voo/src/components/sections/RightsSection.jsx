import { Button } from '@/components/ui/button';

const RightsSection = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center">
          Conheça os direitos do passageiro aéreo
        </h2>
        
        <div className="max-w-3xl mx-auto">
          <p className="mb-8">
            Entenda o que o passageiro pode exigir da companhia aérea em situações de problema com voo, 
            de acordo com a <a href="#" className="text-blue-500 hover:underline">Resolução nº 400 da Anac</a> (Agência Nacional de Aviação Civil) e outras leis brasileiras.
          </p>
          
          <div className="mb-10">
            <h3 className="text-2xl font-bold mb-4">Problema com voo cancelado, voo atrasado ou overbooking</h3>
            <p className="mb-4">
              É seu direito escolher entre receber reembolso, remarcar a viagem de avião para uma data da sua preferência 
              ou aguardar o próximo voo para o mesmo destino. Se você precisar esperar no aeroporto, a empresa também deve 
              oferecer assistência material.
            </p>
            <p className="mb-4">
              Além disso, a legislação garante ao passageiro o direito à indenização por danos morais nas seguintes condições:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li className="mb-2">
                A companhia aérea não avisou sobre a alteração pelo menos 72h antes do horário previsto para o voo.
              </li>
              <li>
                O problema com voo gerou um atraso de 4h ou mais na chegada ao destino final.
              </li>
            </ul>
          </div>
          
          <div className="mb-10">
            <h3 className="text-2xl font-bold mb-4">Problema com extravio de bagagem</h3>
            <p className="mb-4">
              Como determinado pela Anac, a companhia aérea deve devolver a bagagem extraviada ao passageiro no prazo 
              de até 7 dias para voos nacionais e 21 dias para voos internacionais.
            </p>
            <p>
              Porém, se o passageiro não receber a bagagem em 3 dias, já pode entrar com uma ação contra a companhia 
              aérea e pedir uma indenização por danos morais.
            </p>
          </div>
          
          <div className="text-center">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white">
              Recupere seus direitos agora
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RightsSection;

