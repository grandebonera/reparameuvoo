import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section className="bg-gradient-to-r from-blue-500 to-blue-400 text-white pt-28 pb-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
          Recupere até R$10.000 por problemas com seu voo
        </h1>
        <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto">
          Descubra em menos de 3 minutos se você tem direito à indenização
        </p>
        <Button className="bg-white text-blue-500 hover:bg-gray-100 text-lg py-6 px-8">
          Verificar meu caso gratuitamente
        </Button>
      </div>
    </section>
  );
};

export default HeroSection;

