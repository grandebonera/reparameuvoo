const StatisticsSection = () => {
  const stats = [
    {
      id: 1,
      number: "90%",
      description: "Taxa de sucesso nos casos que assumimos. Trabalhamos com advogados especializados em direito do consumidor."
    },
    {
      id: 2,
      number: "Milhões",
      description: "Em indenizações recuperadas para nossos clientes através da aplicação correta da lei."
    },
    {
      id: 3,
      number: "Milhares",
      description: "De pessoas já confiaram no Repara meu voo para resolver seus problemas com companhias aéreas."
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat) => (
            <div key={stat.id} className="text-center">
              <div className="text-5xl font-bold text-blue-500 mb-4">{stat.number}</div>
              <p className="text-gray-700">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatisticsSection;

