import { Button } from '@/components/ui/button';
import { X, Clock, Users, HelpCircle } from 'lucide-react';

const CategoriesSection = () => {
  const categories = [
    {
      id: 1,
      title: "Voo cancelado",
      icon: <X className="w-12 h-12 text-blue-500" />,
      description: "Seu voo foi cancelado e você não foi avisado com antecedência? Você pode ter direito a indenização."
    },
    {
      id: 2,
      title: "Voo atrasado",
      icon: <Clock className="w-12 h-12 text-blue-500" />,
      description: "Atraso superior a 4 horas? Você pode ter direito a compensação financeira."
    },
    {
      id: 3,
      title: "Overbooking",
      icon: <Users className="w-12 h-12 text-blue-500" />,
      description: "Não conseguiu embarcar porque a companhia vendeu mais passagens que assentos?"
    },
    {
      id: 4,
      title: "Bagagem extraviada",
      icon: <HelpCircle className="w-12 h-12 text-blue-500" />,
      description: "Sua bagagem foi extraviada ou danificada? Você tem direito a indenização."
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Ajudamos você a recuperar seus direitos
        </h2>
        <p className="text-xl text-center mb-12 max-w-3xl mx-auto">
          Veja em quais casos de problema com voo nós podemos fazer você ganhar uma compensação financeira.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((category) => (
            <div 
              key={category.id} 
              className="bg-white p-8 rounded-lg shadow-md flex flex-col items-center text-center"
            >
              <div className="mb-4">
                {category.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{category.title}</h3>
              <p className="mb-6 text-gray-700">{category.description}</p>
              <Button className="bg-blue-500 hover:bg-blue-600 text-white mt-auto">
                Avaliar meu caso
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;

