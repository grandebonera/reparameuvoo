import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-gray-200 rounded-lg mb-4 overflow-hidden">
      <button
        className="w-full flex justify-between items-center p-4 text-left font-medium focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
      >
        {question}
        <span>
          {isOpen ? (
            <ChevronUp className="w-5 h-5" />
          ) : (
            <ChevronDown className="w-5 h-5" />
          )}
        </span>
      </button>
      
      {isOpen && (
        <div className="p-4 bg-gray-50 border-t border-gray-200">
          <p>{answer}</p>
        </div>
      )}
    </div>
  );
};

const FAQSection = () => {
  const faqs = [
    {
      id: 1,
      question: "O que fazer em caso de problema com voo?",
      answer: "Em caso de problema com voo, é importante guardar todos os comprovantes (bilhetes, recibos, e-mails) e registrar uma reclamação formal com a companhia aérea. Se não obtiver resposta satisfatória, você pode buscar seus direitos através do Repara meu voo."
    },
    {
      id: 2,
      question: "Quando a companhia aérea deve oferecer assistência material?",
      answer: "A companhia aérea deve oferecer assistência material aos passageiros em caso de atraso, cancelamento ou interrupção de voo. Esta assistência varia conforme o tempo de espera: a partir de 1 hora (comunicação), 2 horas (alimentação) e 4 horas (hospedagem, se necessário)."
    },
    {
      id: 3,
      question: "Com qual antecedência a companhia aérea pode fazer alterações em voo?",
      answer: "A companhia aérea deve informar o passageiro sobre alterações no voo com pelo menos 72 horas de antecedência. Caso contrário, o passageiro pode ter direito a indenização por danos morais."
    },
    {
      id: 4,
      question: "O que fazer quando o voo é cancelado de última hora?",
      answer: "Quando o voo é cancelado de última hora, o passageiro tem direito a escolher entre: reembolso integral, reacomodação em outro voo (da mesma companhia ou de outra) ou execução do serviço por outra modalidade de transporte. Além disso, a companhia deve oferecer assistência material."
    },
    {
      id: 5,
      question: "Quando posso exigir indenização por problema com voo?",
      answer: "Você pode exigir indenização quando: o voo atrasar mais de 4 horas, for cancelado sem aviso prévio de 72 horas, houver overbooking, ou sua bagagem for extraviada. Cada caso é analisado individualmente para determinar o valor da indenização."
    },
    {
      id: 6,
      question: "Quando posso receber indenização por extravio de bagagem?",
      answer: "Se sua bagagem não for devolvida em até 7 dias (voos nacionais) ou 21 dias (voos internacionais), você tem direito a indenização. No entanto, você já pode iniciar um processo após 3 dias sem receber sua bagagem."
    },
    {
      id: 7,
      question: "Qual é o valor da indenização por problema com voo?",
      answer: "O valor da indenização varia conforme cada caso, podendo chegar a R$10.000 ou mais. Fatores como o tipo de problema, tempo de atraso, transtornos causados e jurisprudência são considerados para determinar o valor."
    }
  ];

  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          Dúvidas frequentes sobre problemas com voos
        </h2>
        
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq) => (
            <FAQItem 
              key={faq.id} 
              question={faq.question} 
              answer={faq.answer} 
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;

