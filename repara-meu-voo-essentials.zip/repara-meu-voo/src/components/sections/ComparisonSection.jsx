import { X, Check } from 'lucide-react';

const ComparisonSection = () => {
  const traditionalMethod = [
    {
      id: 1,
      text: "Complicado: Você precisa cuidar de tudo sozinho(a) e lidar diretamente com a empresa."
    },
    {
      id: 2,
      text: "Muita dor de cabeça: Quando algo dá errado, você não sabe quem buscar para tirar suas dúvidas."
    },
    {
      id: 3,
      text: "Arriscado: Você pode não conseguir levar o processo adiante e as chances de fazer justiça ficam bem distantes."
    },
    {
      id: 4,
      text: "Custos altos: Se você finalmente conseguir ir para a Justiça, terá despesas com advogados e custos da justiça comum, mesmo que perca a causa."
    },
    {
      id: 5,
      text: "Falta de transparência: Você pode ficar muito tempo no escuro, sem saber o que está acontecendo com seu caso."
    }
  ];

  const ourMethod = [
    {
      id: 1,
      text: "Praticidade e segurança: Sabemos que seu tempo é valioso. Tudo será resolvido pela nossa equipe e você não precisa se preocupar com a burocracia."
    },
    {
      id: 2,
      text: "Especialistas na área: Contamos com uma rede de advogados especializados em direito do consumidor para resolver o seu problema."
    },
    {
      id: 3,
      text: "Baixo risco: Nós garantimos que o seu processo vai adiante até a decisão final. Milhares de pessoas já decidiram fazer justiça conosco e receberam sua indenização."
    },
    {
      id: 4,
      text: "Só paga se ganhar: Você não precisa pagar nada para começar a fazer justiça, e só cobraremos nossa taxa de serviço se e quando você receber a sua indenização."
    },
    {
      id: 5,
      text: "Transparência na palma da mão: Você receberá atualizações com frequência e pode tirar suas dúvidas a qualquer momento."
    }
  ];

  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          Por que escolher o Repara meu voo?
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-red-50 p-8 rounded-lg">
            <h3 className="text-2xl font-bold mb-6 text-center">Método tradicional</h3>
            
            <div className="space-y-6">
              {traditionalMethod.map((item) => (
                <div key={item.id} className="flex">
                  <div className="mr-4 mt-1">
                    <X className="w-5 h-5 text-red-500" />
                  </div>
                  <p>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-blue-50 p-8 rounded-lg">
            <h3 className="text-2xl font-bold mb-6 text-center">Com o Repara meu voo</h3>
            
            <div className="space-y-6">
              {ourMethod.map((item) => (
                <div key={item.id} className="flex">
                  <div className="mr-4 mt-1">
                    <Check className="w-5 h-5 text-green-500" />
                  </div>
                  <p>{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;

