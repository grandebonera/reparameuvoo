import { Button } from '@/components/ui/button';
import { Search, Mail, BarChart2, Scale } from 'lucide-react';

const HowItWorksSection = () => {
  const steps = [
    {
      id: 1,
      icon: <Search className="w-12 h-12 text-blue-500" />,
      title: "Descubra seus direitos",
      description: "Acesse nosso site e descubra a elegibilidade do seu caso. É rápido, fácil e grátis!"
    },
    {
      id: 2,
      icon: <Mail className="w-12 h-12 text-blue-500" />,
      title: "Envie seu caso",
      description: "Conte sua história e envie as provas do caso. Nossa equipe jurídica cuida de tudo para você!"
    },
    {
      id: 3,
      icon: <BarChart2 className="w-12 h-12 text-blue-500" />,
      title: "Acompanhe o processo",
      description: "Veja o status do seu processo quando quiser, em tempo real. Para nós, transparência é prioridade!"
    },
    {
      id: 4,
      icon: <Scale className="w-12 h-12 text-blue-500" />,
      title: "Receba sua indenização",
      description: "Aqui, você só paga pelo nosso serviço quando receber a indenização. Se não ganhar, não paga nada!"
    }
  ];

  return (
    <section className="bg-gray-50 py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center">
          Recupere seus direitos de forma simples e rápida
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {steps.map((step) => (
            <div key={step.id} className="flex flex-col items-center text-center">
              <div className="mb-4">
                {step.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{step.title}</h3>
              <p className="text-gray-700">{step.description}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <Button className="bg-blue-500 hover:bg-blue-600 text-white text-lg py-6 px-8">
            Verificar meu caso agora
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;

