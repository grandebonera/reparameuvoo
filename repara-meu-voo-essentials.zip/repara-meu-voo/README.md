# Repara meu voo

Site da empresa "Repara meu voo", especializada em recuperação de direitos de passageiros aéreos.

## Visão Geral

O site "Repara meu voo" foi desenvolvido para ajudar passageiros a recuperarem seus direitos em casos de problemas com voos, como cancelamentos, atrasos, overbooking e extravio de bagagem. O site oferece informações sobre os direitos dos passageiros e permite que os usuários verifiquem se têm direito a indenização.

## Tecnologias Utilizadas

- React
- Vite
- Tailwind CSS
- Shadcn/UI
- Lucide Icons

## Estrutura do Projeto

```
repara-meu-voo/
├── public/
├── src/
│   ├── assets/
│   │   └── icons/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.jsx
│   │   │   └── Footer.jsx
│   │   ├── sections/
│   │   │   ├── HeroSection.jsx
│   │   │   ├── CredibilitySection.jsx
│   │   │   ├── CategoriesSection.jsx
│   │   │   ├── ProcessSection.jsx
│   │   │   ├── StatisticsSection.jsx
│   │   │   ├── HowItWorksSection.jsx
│   │   │   ├── PricingSection.jsx
│   │   │   ├── ComparisonSection.jsx
│   │   │   ├── RightsSection.jsx
│   │   │   └── FAQSection.jsx
│   │   └── ui/
│   ├── App.jsx
│   ├── App.css
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Desenvolvimento Local

### Pré-requisitos

- Node.js (v18 ou superior)
- pnpm (v8 ou superior)

### Instalação

1. Clone o repositório
   ```bash
   git clone [url_do_repositorio]
   ```

2. Navegue até o diretório do projeto
   ```bash
   cd repara-meu-voo
   ```

3. Instale as dependências
   ```bash
   pnpm install
   ```

### Execução

1. Inicie o servidor de desenvolvimento
   ```bash
   pnpm run dev
   ```

2. Acesse o site em [http://localhost:5173](http://localhost:5173)

### Build

Para gerar a versão de produção do site:

```bash
pnpm run build
```

Os arquivos de produção serão gerados na pasta `dist`.

## Hospedagem

Para instruções detalhadas sobre como hospedar o site no Digital Ocean, consulte o arquivo `instrucoes_hospedagem_digital_ocean.md`.

## Acesso FTP e Edições

Para instruções sobre como acessar o site via FTP e implementar edições, consulte o arquivo `instrucoes_acesso_ftp.md`.

## Personalização

### Alterando o Conteúdo

A maioria do conteúdo do site está nos componentes da pasta `src/components/sections/`. Para alterar o texto, basta editar os arquivos correspondentes.

### Alterando o Estilo

O site utiliza Tailwind CSS para estilização. As classes de estilo estão diretamente nos componentes. Para alterações mais profundas, você pode editar o arquivo `src/index.css`.

### Adicionando Novas Páginas

Para adicionar novas páginas ao site:

1. Crie um novo componente na pasta `src/components/pages/`
2. Adicione a rota no arquivo `src/App.jsx`

## Suporte

Para suporte técnico ou dúvidas sobre o site, entre em contato com:

- Email: [seu_email@exemplo.com]
- Telefone: [seu_telefone]

