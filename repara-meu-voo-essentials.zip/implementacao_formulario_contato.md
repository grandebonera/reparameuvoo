# Implementação de Formulário de Contato Funcional

## Visão Geral

Este documento contém instruções para implementar um formulário de contato funcional no site "Repara meu voo". O formulário permitirá que os usuários enviem mensagens diretamente pelo site, que serão encaminhadas para o email da empresa.

## Opções de Implementação

Existem várias maneiras de implementar um formulário de contato funcional:

### 1. Usando um Serviço de Formulários de Terceiros (Recomendado para sites estáticos)

Serviços como Formspree, Netlify Forms ou FormSubmit permitem implementar formulários funcionais em sites estáticos sem necessidade de backend.

#### Implementação com Formspree

1. **Crie uma conta no Formspree**
   - Acesse [https://formspree.io/](https://formspree.io/)
   - Crie uma conta gratuita

2. **Crie um novo formulário**
   - No painel do Formspree, clique em "New Form"
   - Dê um nome ao formulário (ex: "Repara meu voo - Contato")
   - Copie o endpoint fornecido (será algo como `https://formspree.io/f/xrgdopqz`)

3. **Adicione o componente de formulário ao site**
   - Crie um novo arquivo `src/components/sections/ContactForm.jsx`:

```jsx
import { useState } from 'react';
import { Button } from '@/components/ui/button';

const ContactForm = () => {
  const [formStatus, setFormStatus] = useState({
    submitted: false,
    submitting: false,
    error: null
  });
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormStatus({ submitted: false, submitting: true, error: null });
    
    try {
      const response = await fetch('https://formspree.io/f/SEU_ENDPOINT_AQUI', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      
      if (response.ok) {
        setFormStatus({ submitted: true, submitting: false, error: null });
        setFormData({ name: '', email: '', phone: '', message: '' });
      } else {
        const error = await response.json();
        throw new Error(error.message);
      }
    } catch (error) {
      setFormStatus({ submitted: false, submitting: false, error: error.message });
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
          Entre em contato
        </h2>
        <p className="text-xl text-center mb-12 max-w-3xl mx-auto">
          Preencha o formulário abaixo para entrar em contato conosco. Nossa equipe responderá o mais breve possível.
        </p>
        
        <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
          {formStatus.submitted ? (
            <div className="text-center py-8">
              <h3 className="text-2xl font-bold text-green-600 mb-4">Mensagem enviada com sucesso!</h3>
              <p className="mb-6">Obrigado por entrar em contato. Responderemos em breve.</p>
              <Button 
                className="bg-blue-500 hover:bg-blue-600 text-white"
                onClick={() => setFormStatus({ submitted: false, submitting: false, error: null })}
              >
                Enviar nova mensagem
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                  Nome completo
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                  Telefone
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                  Mensagem
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="5"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                ></textarea>
              </div>
              
              <Button 
                type="submit"
                className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                disabled={formStatus.submitting}
              >
                {formStatus.submitting ? 'Enviando...' : 'Enviar mensagem'}
              </Button>
              
              {formStatus.error && (
                <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-md">
                  Ocorreu um erro ao enviar sua mensagem. Por favor, tente novamente.
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
```

4. **Substitua o endpoint do Formspree**
   - Substitua `'https://formspree.io/f/SEU_ENDPOINT_AQUI'` pelo endpoint que você copiou do Formspree

5. **Adicione o componente ao App.jsx**
   - Importe o componente no arquivo `src/App.jsx`:
   ```jsx
   import ContactForm from './components/sections/ContactForm'
   ```
   
   - Adicione o componente na seção principal, antes do Footer:
   ```jsx
   <main className="flex-grow pt-16">
     {/* ... outros componentes ... */}
     <ContactForm />
   </main>
   ```

### 2. Usando um Backend Simples (Para mais controle)

Se você preferir mais controle sobre o processamento dos formulários, pode implementar um backend simples usando Node.js e Express.

#### Implementação com Node.js e Express

1. **Crie uma pasta para o backend**
   ```bash
   mkdir -p backend
   cd backend
   ```

2. **Inicialize um projeto Node.js**
   ```bash
   npm init -y
   ```

3. **Instale as dependências necessárias**
   ```bash
   npm install express cors nodemailer dotenv
   ```

4. **Crie um arquivo .env para as variáveis de ambiente**
   ```
   PORT=3000
   EMAIL_USER=seu_email@gmail.com
   EMAIL_PASS=sua_senha_de_app
   EMAIL_TO=destinatario@exemplo.com
   ```

5. **Crie o arquivo server.js**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const nodemailer = require('nodemailer');
   require('dotenv').config();

   const app = express();
   const port = process.env.PORT || 3000;

   // Middleware
   app.use(cors());
   app.use(express.json());

   // Configuração do transporte de email
   const transporter = nodemailer.createTransport({
     service: 'gmail',
     auth: {
       user: process.env.EMAIL_USER,
       pass: process.env.EMAIL_PASS
     }
   });

   // Rota para envio de email
   app.post('/api/contact', async (req, res) => {
     const { name, email, phone, message } = req.body;
     
     if (!name || !email || !message) {
       return res.status(400).json({ error: 'Por favor, preencha todos os campos obrigatórios.' });
     }
     
     try {
       await transporter.sendMail({
         from: `"Formulário de Contato" <${process.env.EMAIL_USER}>`,
         to: process.env.EMAIL_TO,
         subject: `Nova mensagem de contato de ${name}`,
         text: `
           Nome: ${name}
           Email: ${email}
           Telefone: ${phone || 'Não informado'}
           
           Mensagem:
           ${message}
         `,
         html: `
           <h2>Nova mensagem de contato</h2>
           <p><strong>Nome:</strong> ${name}</p>
           <p><strong>Email:</strong> ${email}</p>
           <p><strong>Telefone:</strong> ${phone || 'Não informado'}</p>
           <p><strong>Mensagem:</strong></p>
           <p>${message.replace(/\n/g, '<br>')}</p>
         `
       });
       
       res.status(200).json({ message: 'Mensagem enviada com sucesso!' });
     } catch (error) {
       console.error('Erro ao enviar email:', error);
       res.status(500).json({ error: 'Ocorreu um erro ao enviar sua mensagem.' });
     }
   });

   // Iniciar o servidor
   app.listen(port, () => {
     console.log(`Servidor rodando na porta ${port}`);
   });
   ```

6. **Modifique o componente ContactForm para usar o backend**
   - Altere a URL do fetch no método handleSubmit:
   ```javascript
   const response = await fetch('http://localhost:3000/api/contact', {
     method: 'POST',
     headers: {
       'Content-Type': 'application/json'
     },
     body: JSON.stringify(formData)
   });
   ```

7. **Execute o backend**
   ```bash
   node server.js
   ```

### 3. Usando um Serviço de Email Serverless (Para sites em produção)

Para sites em produção, você pode usar serviços serverless como AWS Lambda ou Netlify Functions para processar os formulários.

#### Implementação com Netlify Functions

1. **Instale o Netlify CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Inicialize o projeto Netlify**
   ```bash
   netlify init
   ```

3. **Crie uma pasta para as funções**
   ```bash
   mkdir -p netlify/functions
   ```

4. **Crie o arquivo netlify/functions/contact.js**
   ```javascript
   const nodemailer = require('nodemailer');

   exports.handler = async function(event, context) {
     // Apenas permitir método POST
     if (event.httpMethod !== 'POST') {
       return { statusCode: 405, body: 'Method Not Allowed' };
     }
     
     try {
       const { name, email, phone, message } = JSON.parse(event.body);
       
       if (!name || !email || !message) {
         return {
           statusCode: 400,
           body: JSON.stringify({ error: 'Por favor, preencha todos os campos obrigatórios.' })
         };
       }
       
       // Configuração do transporte de email
       const transporter = nodemailer.createTransport({
         service: 'gmail',
         auth: {
           user: process.env.EMAIL_USER,
           pass: process.env.EMAIL_PASS
         }
       });
       
       // Enviar email
       await transporter.sendMail({
         from: `"Formulário de Contato" <${process.env.EMAIL_USER}>`,
         to: process.env.EMAIL_TO,
         subject: `Nova mensagem de contato de ${name}`,
         text: `
           Nome: ${name}
           Email: ${email}
           Telefone: ${phone || 'Não informado'}
           
           Mensagem:
           ${message}
         `,
         html: `
           <h2>Nova mensagem de contato</h2>
           <p><strong>Nome:</strong> ${name}</p>
           <p><strong>Email:</strong> ${email}</p>
           <p><strong>Telefone:</strong> ${phone || 'Não informado'}</p>
           <p><strong>Mensagem:</strong></p>
           <p>${message.replace(/\n/g, '<br>')}</p>
         `
       });
       
       return {
         statusCode: 200,
         body: JSON.stringify({ message: 'Mensagem enviada com sucesso!' })
       };
     } catch (error) {
       console.error('Erro ao enviar email:', error);
       return {
         statusCode: 500,
         body: JSON.stringify({ error: 'Ocorreu um erro ao enviar sua mensagem.' })
       };
     }
   };
   ```

5. **Instale as dependências necessárias**
   ```bash
   npm install nodemailer
   ```

6. **Configure as variáveis de ambiente no Netlify**
   - No painel do Netlify, vá para "Site settings" > "Environment variables"
   - Adicione as variáveis `EMAIL_USER`, `EMAIL_PASS` e `EMAIL_TO`

7. **Modifique o componente ContactForm para usar a função Netlify**
   - Altere a URL do fetch no método handleSubmit:
   ```javascript
   const response = await fetch('/.netlify/functions/contact', {
     method: 'POST',
     headers: {
       'Content-Type': 'application/json'
     },
     body: JSON.stringify(formData)
   });
   ```

## Validação e Segurança

Para garantir a segurança e a qualidade dos dados enviados pelo formulário:

1. **Implemente validação no frontend**
   - Verifique se os campos obrigatórios estão preenchidos
   - Valide o formato do email
   - Limite o tamanho dos campos

2. **Implemente validação no backend**
   - Verifique novamente todos os campos
   - Sanitize os dados para evitar injeção de código

3. **Implemente proteção contra spam**
   - Adicione um campo honeypot (campo oculto que bots tendem a preencher)
   - Implemente reCAPTCHA

### Exemplo de implementação de reCAPTCHA

1. **Registre seu site no Google reCAPTCHA**
   - Acesse [https://www.google.com/recaptcha/admin](https://www.google.com/recaptcha/admin)
   - Registre seu site e obtenha as chaves

2. **Adicione o script do reCAPTCHA ao index.html**
   ```html
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
   ```

3. **Adicione o componente reCAPTCHA ao formulário**
   ```jsx
   <div className="mb-6">
     <div className="g-recaptcha" data-sitekey="SUA_CHAVE_DO_SITE"></div>
   </div>
   ```

4. **Verifique o token do reCAPTCHA no backend**
   ```javascript
   const verifyRecaptcha = async (token) => {
     const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/x-www-form-urlencoded'
       },
       body: `secret=SUA_CHAVE_SECRETA&response=${token}`
     });
     
     const data = await response.json();
     return data.success;
   };
   ```

## Considerações Finais

- Teste o formulário exaustivamente antes de colocá-lo em produção
- Configure notificações para garantir que você seja alertado quando receber uma nova mensagem
- Considere adicionar uma página de confirmação após o envio do formulário
- Mantenha as credenciais de email seguras e não as exponha no código-fonte
- Atualize regularmente as dependências para evitar vulnerabilidades de segurança

