# Instruções para Hospedagem no Digital Ocean

## Visão Geral

Este documento contém instruções para hospedar o site "Repara meu voo" no Digital Ocean. O site foi desenvolvido usando React e Vite, e a versão de produção já foi gerada na pasta `dist`.

## Opções de Hospedagem no Digital Ocean

Existem várias maneiras de hospedar o site no Digital Ocean:

### 1. Usando o App Platform (Recomendado)

O Digital Ocean App Platform é uma plataforma PaaS (Platform as a Service) que facilita a implantação de aplicativos web. É a opção mais simples e recomendada para hospedar sites estáticos como o "Repara meu voo".

#### Passos para Implantação:

1. **Crie uma conta no Digital Ocean** (se ainda não tiver uma)
   - Acesse [https://www.digitalocean.com/](https://www.digitalocean.com/)
   - Clique em "Sign Up" e siga as instruções

2. **Acesse o App Platform**
   - No painel do Digital Ocean, clique em "Apps" no menu lateral
   - Clique em "Create App"

3. **Configure o aplicativo**
   - Escolha "GitHub" como fonte do código (ou faça upload do diretório `dist`)
   - Selecione o repositório onde você armazenou o código do site
   - Escolha a branch principal (geralmente `main` ou `master`)
   - Selecione o tipo de aplicativo como "Static Site"
   - Configure o diretório de build como `dist`
   - Escolha o plano Basic ($5/mês) para começar

4. **Finalize a configuração**
   - Escolha um nome para o aplicativo
   - Selecione a região mais próxima dos seus usuários
   - Revise as configurações e clique em "Launch App"

5. **Configure seu domínio personalizado** (opcional)
   - No painel do aplicativo, vá para a aba "Settings"
   - Clique em "Domains"
   - Adicione seu domínio personalizado e siga as instruções para configurar os registros DNS

### 2. Usando um Droplet (Servidor VPS)

Se você preferir mais controle sobre o ambiente de hospedagem, pode usar um Droplet do Digital Ocean, que é um servidor virtual privado (VPS).

#### Passos para Implantação:

1. **Crie um Droplet**
   - No painel do Digital Ocean, clique em "Droplets" no menu lateral
   - Clique em "Create Droplet"
   - Escolha Ubuntu 22.04 como sistema operacional
   - Selecione o plano Basic ($5/mês para começar)
   - Escolha a região mais próxima dos seus usuários
   - Adicione sua chave SSH ou crie uma senha
   - Clique em "Create Droplet"

2. **Conecte-se ao Droplet via SSH**
   ```bash
   ssh root@seu_ip_do_droplet
   ```

3. **Instale o Nginx**
   ```bash
   apt update
   apt install nginx -y
   ```

4. **Configure o Firewall**
   ```bash
   ufw allow 'Nginx Full'
   ufw allow OpenSSH
   ufw enable
   ```

5. **Faça upload dos arquivos do site**
   - Use SCP ou SFTP para transferir os arquivos da pasta `dist` para o servidor
   ```bash
   scp -r /caminho/para/dist/* root@seu_ip_do_droplet:/var/www/html/
   ```

6. **Configure o Nginx**
   ```bash
   nano /etc/nginx/sites-available/default
   ```
   
   Substitua o conteúdo pelo seguinte:
   ```nginx
   server {
       listen 80;
       listen [::]:80;
       
       root /var/www/html;
       index index.html;
       
       server_name seu_dominio.com www.seu_dominio.com;
       
       location / {
           try_files $uri $uri/ /index.html;
       }
   }
   ```

7. **Reinicie o Nginx**
   ```bash
   systemctl restart nginx
   ```

8. **Configure seu domínio** (opcional)
   - No painel de controle do seu provedor de domínio, configure os registros DNS para apontar para o IP do seu Droplet

### 3. Usando Spaces (Armazenamento de Objetos)

O Digital Ocean Spaces é um serviço de armazenamento de objetos compatível com S3 que pode ser usado para hospedar sites estáticos.

#### Passos para Implantação:

1. **Crie um Space**
   - No painel do Digital Ocean, clique em "Spaces" no menu lateral
   - Clique em "Create Space"
   - Escolha a região mais próxima dos seus usuários
   - Dê um nome ao seu Space
   - Marque a opção "CDN" para habilitar a rede de distribuição de conteúdo
   - Clique em "Create Space"

2. **Faça upload dos arquivos**
   - No painel do Space, clique em "Upload"
   - Faça upload de todos os arquivos da pasta `dist`
   - Certifique-se de que o arquivo `index.html` esteja na raiz do Space

3. **Configure o acesso público**
   - No painel do Space, vá para a aba "Settings"
   - Em "File Listing", selecione "Public"
   - Em "CORS", configure para permitir acesso de qualquer origem

4. **Configure o site estático**
   - No painel do Space, vá para a aba "Settings"
   - Em "Static Site Hosting", clique em "Enable"
   - Defina o documento de índice como `index.html`
   - Defina o documento de erro como `index.html` (para suportar rotas do React)

5. **Configure seu domínio personalizado** (opcional)
   - No painel do Space, vá para a aba "Settings"
   - Em "Domains", adicione seu domínio personalizado
   - Siga as instruções para configurar os registros DNS

## Manutenção e Atualizações

Para atualizar o site no futuro:

1. Faça as alterações necessárias no código-fonte
2. Execute `pnpm run build` para gerar uma nova versão de produção
3. Faça upload dos novos arquivos para o Digital Ocean, substituindo os arquivos antigos

## Suporte

Se precisar de ajuda com a hospedagem, você pode:

- Consultar a [documentação oficial do Digital Ocean](https://docs.digitalocean.com/)
- Entrar em contato com o suporte do Digital Ocean
- Solicitar assistência adicional para configuração e manutenção do site

## Próximos Passos

Após a hospedagem do site, recomendamos:

1. Configurar HTTPS para garantir a segurança do site
2. Configurar backups regulares
3. Monitorar o desempenho e o tráfego do site
4. Considerar a implementação de um sistema de gerenciamento de conteúdo (CMS) para facilitar atualizações futuras

