# Instruções para a Versão de Produção do Site

## Visão Geral

Este documento contém instruções para gerar e implantar a versão de produção do site "Repara meu voo". A versão de produção é otimizada para desempenho e pronta para ser hospedada em um servidor web.

## Gerando a Versão de Produção

### Pré-requisitos

- Node.js (v18 ou superior)
- pnpm (v8 ou superior)

### Passos para Gerar a Versão de Produção

1. **Clone o repositório ou extraia o arquivo compactado**
   ```bash
   git clone [url_do_repositorio]
   # ou
   unzip repara-meu-voo-essentials.zip
   ```

2. **Navegue até o diretório do projeto**
   ```bash
   cd repara-meu-voo
   ```

3. **Instale as dependências**
   ```bash
   pnpm install
   ```

4. **Gere a versão de produção**
   ```bash
   pnpm run build
   ```

5. **Verifique a pasta `dist`**
   ```bash
   ls -la dist
   ```

   A pasta `dist` contém todos os arquivos necessários para a versão de produção do site, incluindo:
   - `index.html`: O arquivo HTML principal
   - `assets/`: Pasta com arquivos CSS, JavaScript e outros recursos

## Implantando a Versão de Produção

### Opção 1: Hospedagem no Digital Ocean

Para hospedar o site no Digital Ocean, siga as instruções detalhadas no arquivo `instrucoes_hospedagem_digital_ocean.md`.

### Opção 2: Hospedagem em Outro Provedor

Se você estiver usando outro provedor de hospedagem, siga estas etapas gerais:

1. **Faça upload dos arquivos da pasta `dist` para o servidor**
   - Use FTP, SFTP ou outro método de transferência de arquivos
   - Certifique-se de fazer upload de todos os arquivos e pastas dentro da pasta `dist`

2. **Configure o servidor web**
   - Se estiver usando Apache, certifique-se de que o arquivo `.htaccess` está configurado corretamente para lidar com rotas do React
   - Se estiver usando Nginx, configure o servidor para redirecionar todas as solicitações para `index.html`

3. **Configure HTTPS**
   - Recomendamos fortemente configurar HTTPS para o seu site
   - Você pode usar Let's Encrypt para obter certificados SSL gratuitos

### Opção 3: Hospedagem em Serviços de Hospedagem Estática

Você também pode hospedar o site em serviços de hospedagem estática como:

1. **Netlify**
   - Crie uma conta no Netlify
   - Arraste e solte a pasta `dist` na interface do Netlify
   - Ou configure o Netlify para fazer build diretamente do repositório Git

2. **Vercel**
   - Crie uma conta no Vercel
   - Importe o repositório Git
   - Configure o comando de build como `pnpm run build`
   - Configure o diretório de saída como `dist`

3. **GitHub Pages**
   - Crie um repositório no GitHub
   - Configure o GitHub Actions para fazer build e deploy do site
   - Ou faça upload manual dos arquivos da pasta `dist` para a branch `gh-pages`

## Testando a Versão de Produção Localmente

Antes de implantar o site em produção, você pode testá-lo localmente:

1. **Instale um servidor web local**
   ```bash
   pnpm install -g serve
   ```

2. **Sirva a pasta `dist`**
   ```bash
   serve -s dist
   ```

3. **Acesse o site em [http://localhost:3000](http://localhost:3000)**

## Otimizações Adicionais

Para melhorar ainda mais o desempenho do site em produção:

1. **Otimize imagens**
   - Use ferramentas como ImageOptim, TinyPNG ou Squoosh para otimizar imagens
   - Considere usar formatos modernos como WebP

2. **Configure cache**
   - Configure cabeçalhos de cache apropriados para recursos estáticos
   - Use um CDN (Content Delivery Network) para melhorar o tempo de carregamento

3. **Monitore o desempenho**
   - Use ferramentas como Google PageSpeed Insights ou Lighthouse para monitorar o desempenho
   - Faça ajustes conforme necessário

## Solução de Problemas

### Problemas Comuns

1. **Rotas não funcionam após atualização da página**
   - Certifique-se de que o servidor está configurado para redirecionar todas as solicitações para `index.html`
   - Para Apache, adicione um arquivo `.htaccess` na pasta `dist`:
     ```
     RewriteEngine On
     RewriteBase /
     RewriteRule ^index\.html$ - [L]
     RewriteCond %{REQUEST_FILENAME} !-f
     RewriteCond %{REQUEST_FILENAME} !-d
     RewriteRule . /index.html [L]
     ```
   - Para Nginx, adicione esta configuração:
     ```
     location / {
       try_files $uri $uri/ /index.html;
     }
     ```

2. **Recursos não carregam**
   - Verifique se os caminhos para os recursos estão corretos
   - Verifique se todos os arquivos foram transferidos corretamente
   - Verifique os erros no console do navegador

3. **Problemas de CORS**
   - Configure os cabeçalhos CORS apropriados no servidor
   - Certifique-se de que todas as APIs externas permitem solicitações do seu domínio

## Suporte

Se precisar de ajuda com a versão de produção do site, você pode:

- Consultar a documentação do React e Vite
- Consultar a documentação do seu provedor de hospedagem
- Solicitar assistência adicional para configuração e manutenção do site

