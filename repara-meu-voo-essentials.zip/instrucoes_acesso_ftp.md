# Instruções para Acesso FTP e Implementação de Edições

## Visão Geral

Este documento contém instruções para acessar o site "Repara meu voo" via FTP e implementar edições futuras. O FTP (File Transfer Protocol) é um método para transferir arquivos entre um cliente e um servidor em uma rede de computadores.

## Configuração de Acesso FTP

### Pré-requisitos

- Um cliente FTP instalado em seu computador (recomendamos [FileZilla](https://filezilla-project.org/) ou [Cyberduck](https://cyberduck.io/))
- Credenciais de acesso FTP fornecidas pelo seu provedor de hospedagem

### Configuração no Digital Ocean

Se você estiver usando um Droplet do Digital Ocean, siga estas etapas para configurar o acesso FTP:

1. **Instale o servidor FTP (vsftpd)**
   ```bash
   apt update
   apt install vsftpd -y
   ```

2. **Configure o servidor FTP**
   ```bash
   nano /etc/vsftpd.conf
   ```
   
   Certifique-se de que as seguintes linhas estejam descomentadas ou adicionadas:
   ```
   write_enable=YES
   local_umask=022
   chroot_local_user=YES
   allow_writeable_chroot=YES
   pasv_enable=YES
   pasv_min_port=40000
   pasv_max_port=40100
   ```

3. **Reinicie o servidor FTP**
   ```bash
   systemctl restart vsftpd
   ```

4. **Configure o Firewall**
   ```bash
   ufw allow 20/tcp
   ufw allow 21/tcp
   ufw allow 40000:40100/tcp
   ufw reload
   ```

5. **Crie um usuário FTP**
   ```bash
   adduser ftpuser
   ```
   
   Siga as instruções para definir uma senha e outras informações do usuário.

6. **Dê permissões ao usuário FTP**
   ```bash
   chown -R ftpuser:ftpuser /var/www/html
   ```

### Conectando-se via FTP

1. **Abra seu cliente FTP**

2. **Insira as informações de conexão**
   - Servidor: seu_ip_do_servidor ou seu_dominio.com
   - Porta: 21
   - Protocolo: FTP
   - Modo de criptografia: Explícito FTP sobre TLS (se disponível)
   - Usuário: ftpuser (ou o nome de usuário fornecido)
   - Senha: sua_senha

3. **Conecte-se ao servidor**
   - Clique em "Conectar" ou "Iniciar"
   - Aceite o certificado SSL/TLS se solicitado

## Implementando Edições

### Estrutura de Arquivos

A estrutura de arquivos do site em produção é a seguinte:

```
/var/www/html/
├── index.html
├── assets/
│   ├── index-[hash].css
│   ├── index-[hash].js
│   └── [outros arquivos de recursos]
└── [outros arquivos]
```

### Edições Simples

Para edições simples, como alterações de texto ou imagens:

1. **Faça backup dos arquivos originais**
   - Sempre faça um backup antes de fazer alterações

2. **Edite os arquivos HTML diretamente**
   - Para alterações de texto simples, você pode editar o arquivo `index.html`
   - Para substituir imagens, faça upload das novas imagens com os mesmos nomes

### Edições Complexas

Para edições mais complexas, recomendamos o seguinte fluxo de trabalho:

1. **Clone o repositório do código-fonte**
   ```bash
   git clone [url_do_repositorio]
   ```

2. **Instale as dependências**
   ```bash
   cd repara-meu-voo
   pnpm install
   ```

3. **Faça as alterações necessárias**
   - Edite os arquivos de código-fonte conforme necessário

4. **Teste as alterações localmente**
   ```bash
   pnpm run dev
   ```
   - Acesse http://localhost:5173 para visualizar as alterações

5. **Gere a versão de produção**
   ```bash
   pnpm run build
   ```

6. **Faça upload dos arquivos atualizados**
   - Use seu cliente FTP para fazer upload dos arquivos da pasta `dist` para o servidor

### Dicas para Edições

- **Alterações de texto**: Procure pelo texto que deseja alterar no arquivo `index.html` ou nos arquivos JavaScript
- **Alterações de imagens**: Substitua as imagens existentes por novas com o mesmo nome e formato
- **Alterações de estilo**: Edite os arquivos CSS ou adicione novas regras de estilo
- **Adição de novas páginas**: Crie novos componentes React e adicione-os às rotas

## Melhores Práticas

1. **Sempre faça backup antes de fazer alterações**
2. **Teste todas as alterações localmente antes de fazer upload**
3. **Mantenha um registro das alterações feitas**
4. **Verifique a compatibilidade com diferentes navegadores**
5. **Otimize imagens antes de fazer upload**
6. **Verifique se o site continua responsivo após as alterações**

## Solução de Problemas

### Problemas Comuns de FTP

1. **Não consegue conectar**
   - Verifique se o endereço do servidor, nome de usuário e senha estão corretos
   - Verifique se o firewall do servidor permite conexões FTP
   - Tente usar o modo passivo

2. **Permissão negada**
   - Verifique se o usuário FTP tem permissões adequadas para os diretórios
   - Execute o comando `chmod` para ajustar as permissões

3. **Arquivos não aparecem após upload**
   - Verifique se você está fazendo upload para o diretório correto
   - Limpe o cache do navegador e recarregue o site

### Problemas Comuns do Site

1. **Site não carrega após alterações**
   - Verifique se todos os arquivos foram transferidos corretamente
   - Verifique se há erros no console do navegador
   - Restaure o backup se necessário

2. **Estilos ou scripts não funcionam**
   - Verifique se os caminhos para os arquivos CSS e JavaScript estão corretos
   - Verifique se os arquivos foram transferidos corretamente

## Suporte

Se precisar de ajuda com o acesso FTP ou implementação de edições, você pode:

- Consultar a documentação do seu cliente FTP
- Entrar em contato com o suporte do seu provedor de hospedagem
- Solicitar assistência adicional para configuração e manutenção do site

